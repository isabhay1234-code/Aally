# ALLAY — Your Intelligence. Your Control.

Personal AI assistant for Android (Kotlin + Jetpack Compose). **Currently Phase 1: Core Assistant.**

## Status — read this honestly
Written by an AI without access to an Android compiler. **It has NOT been compiled, run, or tested on a phone yet.**
First CI build may need small fixes; send me the error and I'll fix it.

| Phase 1 feature | Code written | Verified |
|---|---|---|
| Dark/cyan UI, animated orb | yes | no |
| Text chat with Gemini | yes | no (needs your API key) |
| Hindi/English/Hinglish replies | via system prompt | no |
| Push-to-talk voice input | yes | no (needs real phone) |
| Text-to-speech + stop button | yes | no |
| Chat history (Room, local) | yes | no |
| Settings: API key (encrypted), model, length, style, language | yes | no |
| Error messages (key, quota, network, blocked...) | yes | parser logic covered by unit tests, not yet run |
| Unit tests (parser, prompt, text cleaner) | written | **not yet run** |

**Not in this version:** web search/research, study tools, long-term memory, phone control, coding mode, other AI providers, background voice, wake phrase. ALLAY says so if asked; it must not invent sources.

## Get the APK (no laptop)
1. Put the files from ALLAY.zip at the root of a GitHub repo (`app/`, `.github/`, `build.gradle.kts` at top level). On a phone: GitHub Codespaces (upload zip, run `unzip`, commit) or Termux + git.
2. Repo > **Actions** > **Android CI** > **Run workflow**.
3. Open the finished run > **Artifacts** > **allay-debug-apk** > unzip > install the `.apk` (allow "Install unknown apps").
4. Red run? Copy the error from the failing step and send it to me.

## First use
1. Get a free key at https://aistudio.google.com/apikey (needs a Google account).
2. ALLAY > **Settings** > paste key > **Save key** > **Test connection**.
3. Go back, type a message, tap **Send**.

## How to test Phase 1 (checklist for your phone)
- [ ] App opens, dark navy screen, cyan orb
- [ ] Settings > Test connection says "Connected"
- [ ] Wrong key shows "Gemini rejected the API key"
- [ ] Airplane mode + Send shows "Couldn't reach Gemini" + Retry works after turning it off
- [ ] Ask in English, Hindi (हिंदी), Hinglish — reply matches your language
- [ ] Follow-up ("explain more simply") uses earlier context
- [ ] Hold mic: permission prompt first time; speak; text sends on release
- [ ] Turn on "Speak replies aloud"; reply is spoken; "Stop speaking" works; pressing mic interrupts speech
- [ ] Close and reopen app: History shows chats; open, delete; "Delete all chat history" works
- [ ] Short/Detailed changes reply length

## Known limits
- Replies are plain text (no formatted tables/markdown).
- Android voice input may need internet and a Google speech engine; Hinglish uses the English (India) recognizer.
- Default model `gemini-2.5-flash` may be retired by Google: change it in Settings.
- The key is typed by you and stored encrypted on the phone. This is fine for personal use; a public release should use a backend proxy.
- No Room/UI automated tests yet (they need an emulator/device).

## Secrets
Never commit keys, `local.properties` or keystores (`.gitignore` blocks them). CI uses no secrets and doesn't sign anything.

See `docs/ARCHITECTURE.md` and `docs/CHECKLIST.md`.
