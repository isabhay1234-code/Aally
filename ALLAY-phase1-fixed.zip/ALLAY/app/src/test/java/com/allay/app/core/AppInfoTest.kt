package com.allay.app.core

import org.junit.Assert.assertEquals
import org.junit.Test

/** Smoke test: only proves the unit-test pipeline runs. Real tests arrive with real features. */
class AppInfoTest {
    @Test
    fun appName_isAllay() = assertEquals("ALLAY", AppInfo.NAME)

    @Test
    fun tagline_matchesSpec() = assertEquals("Your Intelligence. Your Control.", AppInfo.TAGLINE)
}
