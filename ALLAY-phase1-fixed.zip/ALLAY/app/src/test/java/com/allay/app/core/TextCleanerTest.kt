package com.allay.app.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TextCleanerTest {
    @Test fun forSpeech_removesMarkdown() = assertEquals("Hello 1 two", TextCleaner.forSpeech("**Hello**  #1\n`two`"))
    @Test fun detectsHindi() = assertTrue(TextCleaner.hasDevanagari("नमस्ते hello"))
    @Test fun englishIsNotHindi() = assertFalse(TextCleaner.hasDevanagari("namaste"))
}
