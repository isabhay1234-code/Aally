package com.allay.app.ai

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GeminiParserTest {
    private fun kindOf(code: Int, body: String): AiErrorKind? =
        try { GeminiParser.parse(code, body); null } catch (e: AiException) { e.kind }

    @Test
    fun success_joinsTextParts_andSkipsThoughts() {
        val body = """{"candidates":[{"content":{"parts":[{"text":"hidden","thought":true},{"text":"Hello "},{"text":"there"}]}}]}"""
        assertEquals("Hello there", GeminiParser.parse(200, body))
    }

    @Test fun http429_isQuota() = assertEquals(AiErrorKind.QUOTA, kindOf(429, """{"error":{"message":"quota"}}"""))
    @Test fun http400_badKey_isInvalidKey() =
        assertEquals(AiErrorKind.INVALID_KEY, kindOf(400, """{"error":{"message":"API key not valid. Please pass a valid API key."}}"""))
    @Test fun http400_other_isBadRequest() = assertEquals(AiErrorKind.BAD_REQUEST, kindOf(400, """{"error":{"message":"bad"}}"""))
    @Test fun http403_isInvalidKey() = assertEquals(AiErrorKind.INVALID_KEY, kindOf(403, "{}"))
    @Test fun http404_isModelNotFound() = assertEquals(AiErrorKind.MODEL_NOT_FOUND, kindOf(404, "{}"))
    @Test fun http503_isServer() = assertEquals(AiErrorKind.SERVER, kindOf(503, "not json"))

    @Test fun blockedPrompt_isBlocked() =
        assertEquals(AiErrorKind.BLOCKED, kindOf(200, """{"promptFeedback":{"blockReason":"SAFETY"}}"""))
    @Test fun noCandidates_isEmpty() = assertEquals(AiErrorKind.EMPTY, kindOf(200, """{"candidates":[]}"""))
    @Test fun garbage200_isUnknown() = assertEquals(AiErrorKind.UNKNOWN, kindOf(200, "<html>"))

    @Test
    fun requestBody_hasSystemInstruction_andAlternatingRoles() {
        val history = listOf(
            ChatTurn(Role.ASSISTANT, "stray reply"),
            ChatTurn(Role.USER, "first"),
            ChatTurn(Role.USER, "second"),
            ChatTurn(Role.ASSISTANT, "answer"),
        )
        val json = JSONObject(GeminiParser.buildRequestBody(history, "SYSTEM"))
        assertEquals("SYSTEM", json.getJSONObject("systemInstruction").getJSONArray("parts").getJSONObject(0).getString("text"))
        val contents = json.getJSONArray("contents")
        assertEquals(2, contents.length())
        assertEquals("user", contents.getJSONObject(0).getString("role"))
        assertTrue(contents.getJSONObject(0).getJSONArray("parts").getJSONObject(0).getString("text").contains("second"))
        assertEquals("model", contents.getJSONObject(1).getString("role"))
    }
}
