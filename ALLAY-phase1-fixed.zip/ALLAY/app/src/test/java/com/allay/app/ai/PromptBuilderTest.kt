package com.allay.app.ai

import com.allay.app.data.ChatStyle
import com.allay.app.data.ResponseLength
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PromptBuilderTest {
    @Test
    fun includesLengthAndStyle_andHonestyRules() {
        val p = PromptBuilder.system(ResponseLength.SHORT, ChatStyle.TEACHER)
        assertTrue(p.contains("1-3 sentences"))
        assertTrue(p.contains("patient teacher"))
        assertTrue(p.contains("never invent sources"))
        assertTrue(p.contains("Hinglish"))
    }

    @Test
    fun detailedDiffersFromShort() {
        assertFalse(
            PromptBuilder.system(ResponseLength.DETAILED, ChatStyle.FRIENDLY) ==
                PromptBuilder.system(ResponseLength.SHORT, ChatStyle.FRIENDLY),
        )
    }
}
