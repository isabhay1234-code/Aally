package com.allay.app.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.allay.app.security.KeyCipher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "allay_settings")

private inline fun <reified T : Enum<T>> enumOr(name: String?, default: T): T =
    enumValues<T>().firstOrNull { it.name == name } ?: default

class SettingsRepository(private val context: Context) {
    private object Keys {
        val API_KEY = stringPreferencesKey("api_key_encrypted")
        val MODEL = stringPreferencesKey("model")
        val LENGTH = stringPreferencesKey("length")
        val STYLE = stringPreferencesKey("style")
        val LANGUAGE = stringPreferencesKey("voice_language")
        val SPEAK = booleanPreferencesKey("speak_replies")
    }

    val settings: Flow<AppSettings> = context.dataStore.data.map { p ->
        AppSettings(
            apiKey = p[Keys.API_KEY]?.let { KeyCipher.decrypt(it) }.orEmpty(),
            model = p[Keys.MODEL] ?: AppSettings.DEFAULT_MODEL,
            length = enumOr(p[Keys.LENGTH], ResponseLength.BALANCED),
            style = enumOr(p[Keys.STYLE], ChatStyle.FRIENDLY),
            voiceLanguage = enumOr(p[Keys.LANGUAGE], VoiceLanguage.ENGLISH),
            speakReplies = p[Keys.SPEAK] ?: false,
        )
    }.flowOn(Dispatchers.Default)

    suspend fun saveApiKey(key: String) {
        val trimmed = key.trim()
        context.dataStore.edit {
            if (trimmed.isEmpty()) it.remove(Keys.API_KEY) else it[Keys.API_KEY] = KeyCipher.encrypt(trimmed)
        }
    }

    suspend fun saveModel(model: String) {
        context.dataStore.edit { it[Keys.MODEL] = model.trim().ifEmpty { AppSettings.DEFAULT_MODEL } }
    }

    suspend fun setLength(v: ResponseLength) { context.dataStore.edit { it[Keys.LENGTH] = v.name } }
    suspend fun setStyle(v: ChatStyle) { context.dataStore.edit { it[Keys.STYLE] = v.name } }
    suspend fun setVoiceLanguage(v: VoiceLanguage) { context.dataStore.edit { it[Keys.LANGUAGE] = v.name } }
    suspend fun setSpeakReplies(v: Boolean) { context.dataStore.edit { it[Keys.SPEAK] = v } }
}
