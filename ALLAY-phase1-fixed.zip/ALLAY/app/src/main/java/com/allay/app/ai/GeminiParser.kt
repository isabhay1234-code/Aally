package com.allay.app.ai

import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

/** Builds Gemini request JSON and reads responses. Pure logic, no network, unit tested. */
object GeminiParser {

    /** Gemini wants alternating turns starting with the user. Merge neighbours and drop a leading reply. */
    fun normalize(history: List<ChatTurn>): List<ChatTurn> {
        val merged = mutableListOf<ChatTurn>()
        for (turn in history) {
            if (turn.text.isBlank()) continue
            val last = merged.lastOrNull()
            if (last != null && last.role == turn.role) {
                merged[merged.lastIndex] = last.copy(text = last.text + "\n\n" + turn.text)
            } else {
                merged.add(turn)
            }
        }
        while (merged.isNotEmpty() && merged.first().role != Role.USER) merged.removeAt(0)
        return merged
    }

    fun buildRequestBody(history: List<ChatTurn>, systemPrompt: String): String {
        val contents = JSONArray()
        for (turn in normalize(history)) {
            contents.put(
                JSONObject()
                    .put("role", if (turn.role == Role.USER) "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", turn.text))),
            )
        }
        return JSONObject()
            .put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt))),
            )
            .put("contents", contents)
            .toString()
    }

    /** Returns reply text for HTTP 2xx, otherwise throws [AiException]. */
    fun parse(httpCode: Int, body: String): String {
        if (httpCode in 200..299) return parseSuccess(body)
        throw mapError(httpCode, body)
    }

    private fun parseSuccess(body: String): String {
        val root = try {
            JSONObject(body)
        } catch (e: JSONException) {
            throw AiException(AiErrorKind.UNKNOWN, "Unreadable response from Gemini")
        }
        val candidates = root.optJSONArray("candidates")
        if (candidates == null || candidates.length() == 0) {
            val blocked = root.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
            throw AiException(if (blocked.isNotEmpty()) AiErrorKind.BLOCKED else AiErrorKind.EMPTY)
        }
        val candidate = candidates.optJSONObject(0) ?: throw AiException(AiErrorKind.EMPTY)
        val parts = candidate.optJSONObject("content")?.optJSONArray("parts")
        val text = StringBuilder()
        if (parts != null) {
            for (i in 0 until parts.length()) {
                val part = parts.optJSONObject(i) ?: continue
                if (part.optBoolean("thought", false)) continue // skip hidden "thinking" parts
                if (part.has("text")) text.append(part.optString("text"))
            }
        }
        val result = text.toString().trim()
        if (result.isEmpty()) {
            val finish = candidate.optString("finishReason")
            throw AiException(if (finish == "SAFETY" || finish == "PROHIBITED_CONTENT") AiErrorKind.BLOCKED else AiErrorKind.EMPTY)
        }
        return result
    }

    private fun mapError(code: Int, body: String): AiException {
        val message = try {
            JSONObject(body).optJSONObject("error")?.optString("message").orEmpty()
        } catch (e: JSONException) {
            ""
        }
        val kind = when {
            code == 429 -> AiErrorKind.QUOTA
            code == 401 || code == 403 -> AiErrorKind.INVALID_KEY
            code == 400 && message.contains("API key", ignoreCase = true) -> AiErrorKind.INVALID_KEY
            code == 400 -> AiErrorKind.BAD_REQUEST
            code == 404 -> AiErrorKind.MODEL_NOT_FOUND
            code >= 500 -> AiErrorKind.SERVER
            else -> AiErrorKind.UNKNOWN
        }
        return AiException(kind, message.ifEmpty { null })
    }
}
