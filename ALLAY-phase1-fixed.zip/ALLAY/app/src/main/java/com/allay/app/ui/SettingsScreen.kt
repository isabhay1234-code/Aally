package com.allay.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.allay.app.data.ChatStyle
import com.allay.app.data.ResponseLength
import com.allay.app.data.VoiceLanguage
import com.allay.app.ui.chat.ChatViewModel
import com.allay.app.ui.theme.Cyan

@Composable
fun SettingsScreen(vm: ChatViewModel, onBack: () -> Unit) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val testResult by vm.testResult.collectAsStateWithLifecycle()
    val uriHandler = LocalUriHandler.current

    var keyInput by remember { mutableStateOf("") }
    var modelInput by remember(settings.model) { mutableStateOf(settings.model) }
    var confirmClear by remember { mutableStateOf(false) }

    DisposableEffect(Unit) { onDispose { vm.clearTestResult() } }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("Back") }
            Text("Settings", style = MaterialTheme.typography.titleLarge, color = Cyan)
        }

        Heading("Gemini API key")
        Text(
            "Create a free key in Google AI Studio and paste it here. It is stored encrypted on this phone " +
                "and sent only to Google's Gemini API. Free-tier prompts may be used by Google to improve its products; " +
                "check Google's terms.",
            style = MaterialTheme.typography.bodySmall,
        )
        TextButton(onClick = { uriHandler.openUri("https://aistudio.google.com/apikey") }) { Text("Open Google AI Studio") }
        Text(
            if (settings.apiKey.isBlank()) "No key saved yet." else "A key is saved (hidden for safety).",
            color = Cyan,
        )
        OutlinedTextField(
            value = keyInput,
            onValueChange = { keyInput = it },
            label = { Text("Paste API key") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { vm.saveApiKey(keyInput); keyInput = "" }, enabled = keyInput.isNotBlank()) { Text("Save key") }
            TextButton(onClick = { vm.saveApiKey("") }, enabled = settings.apiKey.isNotBlank()) { Text("Remove key") }
        }
        Button(onClick = { vm.testConnection() }, enabled = settings.apiKey.isNotBlank()) { Text("Test connection") }
        testResult?.let { Text(it) }

        Heading("Model")
        OutlinedTextField(
            value = modelInput,
            onValueChange = { modelInput = it },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            supportingText = { Text("Default: ${com.allay.app.data.AppSettings.DEFAULT_MODEL}. Change it if Google retires this model.") },
        )
        Button(onClick = { vm.saveModel(modelInput) }, enabled = modelInput.trim() != settings.model) { Text("Save model") }

        Heading("Response length")
        ChipRow(ResponseLength.values().toList(), settings.length, { it.label }) { vm.setLength(it) }

        Heading("Style")
        ChipRow(ChatStyle.values().toList(), settings.style, { it.label }) { vm.setStyle(it) }

        Heading("Voice input language")
        ChipRow(VoiceLanguage.values().toList(), settings.voiceLanguage, { it.label }) { vm.setVoiceLanguage(it) }
        Text("Hinglish: use English (India) and speak naturally.", style = MaterialTheme.typography.bodySmall)

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Speak replies aloud", modifier = Modifier.weight(1f))
            Switch(checked = settings.speakReplies, onCheckedChange = { vm.setSpeakReplies(it) })
        }

        Heading("Privacy")
        Text(
            "Your chats are saved only on this phone. Each message you send, plus your recent messages " +
                "in that chat, goes to Google Gemini to get a reply. Nothing else is uploaded. " +
                "The microphone is used only while you hold the mic button.",
            style = MaterialTheme.typography.bodySmall,
        )
        Button(onClick = { confirmClear = true }) { Text("Delete all chat history") }
        Text("", modifier = Modifier.padding(bottom = 24.dp))
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Delete all chats?") },
            text = { Text("This permanently removes every saved conversation from this phone.") },
            confirmButton = { TextButton(onClick = { vm.clearAllHistory(); confirmClear = false }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun Heading(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 12.dp))
}

@Composable
private fun <T> ChipRow(options: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { option ->
            FilterChip(selected = option == selected, onClick = { onSelect(option) }, label = { Text(label(option)) })
        }
    }
}
