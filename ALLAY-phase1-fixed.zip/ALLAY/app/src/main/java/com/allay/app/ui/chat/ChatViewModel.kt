package com.allay.app.ui.chat

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.allay.app.AllayApp
import com.allay.app.ai.AiException
import com.allay.app.ai.ChatTurn
import com.allay.app.ai.GeminiProvider
import com.allay.app.ai.PromptBuilder
import com.allay.app.ai.Role
import com.allay.app.data.AppSettings
import com.allay.app.data.ChatStyle
import com.allay.app.data.ConversationEntity
import com.allay.app.data.MessageEntity
import com.allay.app.data.ResponseLength
import com.allay.app.data.VoiceLanguage
import com.allay.app.voice.VoiceController
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class UiError(val message: String, val needsSettings: Boolean, val canRetry: Boolean)

data class ChatUi(
    val loading: Boolean = false,
    val error: UiError? = null,
    val notice: String? = null,
)

class ChatViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as AllayApp
    private val chats = app.chatRepository
    private val settingsRepo = app.settingsRepository

    val voice = VoiceController(application)

    val settings: StateFlow<AppSettings> =
        settingsRepo.settings.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    private val conversationId = MutableStateFlow<Long?>(null)

    @OptIn(ExperimentalCoroutinesApi::class)
    val messages: StateFlow<List<MessageEntity>> = conversationId
        .flatMapLatest { id -> if (id == null) flowOf(emptyList()) else chats.messages(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val conversations: StateFlow<List<ConversationEntity>> = chats.conversations()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _ui = MutableStateFlow(ChatUi())
    val ui: StateFlow<ChatUi> = _ui.asStateFlow()

    private val _testResult = MutableStateFlow<String?>(null)
    val testResult: StateFlow<String?> = _testResult.asStateFlow()

    // ----- chat -----
    fun send(text: String) {
        val message = text.trim()
        if (message.isEmpty() || _ui.value.loading) return
        voice.stopSpeaking()
        viewModelScope.launch {
            _ui.update { it.copy(loading = true, error = null, notice = null) }
            val cid = conversationId.value ?: chats.newConversation(message.take(40)).also { conversationId.value = it }
            chats.addMessage(cid, Role.USER, message)
            requestReply(cid)
        }
    }

    fun retry() {
        val cid = conversationId.value ?: return
        if (_ui.value.loading) return
        viewModelScope.launch { requestReply(cid) }
    }

    private suspend fun requestReply(cid: Long) {
        _ui.update { it.copy(loading = true, error = null) }
        val s = settingsRepo.settings.first()
        try {
            val history = chats.recentTurns(cid, 20) // only the recent window is sent
            val reply = GeminiProvider(s.apiKey, s.model)
                .generate(history, PromptBuilder.system(s.length, s.style))
            chats.addMessage(cid, Role.ASSISTANT, reply)
            if (s.speakReplies) voice.speak(reply)
        } catch (e: AiException) {
            _ui.update { it.copy(error = UiError(e.kind.message, e.kind.needsSettings, e.kind.retryable)) }
        } finally {
            _ui.update { it.copy(loading = false) }
        }
    }

    fun newChat() { voice.stopSpeaking(); conversationId.value = null; _ui.value = ChatUi() }
    fun openConversation(id: Long) { voice.stopSpeaking(); conversationId.value = id; _ui.value = ChatUi() }

    fun deleteConversation(id: Long) {
        viewModelScope.launch {
            chats.delete(id)
            if (conversationId.value == id) conversationId.value = null
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch { chats.clearAll(); conversationId.value = null }
    }

    fun dismissError() = _ui.update { it.copy(error = null) }
    fun dismissNotice() = _ui.update { it.copy(notice = null) }
    fun showNotice(text: String) = _ui.update { it.copy(notice = text) }

    // ----- voice -----
    fun startVoice() {
        voice.startListening(
            languageTag = settings.value.voiceLanguage.tag,
            onText = { send(it) },
            onProblem = { showNotice(it) },
        )
    }

    fun stopVoice() = voice.stopListening()
    fun stopSpeaking() = voice.stopSpeaking()

    // ----- settings -----
    fun saveApiKey(key: String) { viewModelScope.launch { settingsRepo.saveApiKey(key) } }
    fun saveModel(model: String) { viewModelScope.launch { settingsRepo.saveModel(model) } }
    fun setLength(v: ResponseLength) { viewModelScope.launch { settingsRepo.setLength(v) } }
    fun setStyle(v: ChatStyle) { viewModelScope.launch { settingsRepo.setStyle(v) } }
    fun setVoiceLanguage(v: VoiceLanguage) { viewModelScope.launch { settingsRepo.setVoiceLanguage(v) } }
    fun setSpeakReplies(v: Boolean) {
        viewModelScope.launch { settingsRepo.setSpeakReplies(v) }
        if (!v) voice.stopSpeaking()
    }

    fun testConnection() {
        viewModelScope.launch {
            _testResult.value = "Testing..."
            val s = settingsRepo.settings.first()
            _testResult.value = try {
                GeminiProvider(s.apiKey, s.model).generate(
                    listOf(ChatTurn(Role.USER, "Reply with the single word: OK")),
                    "You are a connection test.",
                )
                "Connected. Gemini replied successfully."
            } catch (e: AiException) {
                "Failed: " + e.kind.message
            }
        }
    }

    fun clearTestResult() { _testResult.value = null }

    override fun onCleared() {
        voice.release()
        super.onCleared()
    }
}
