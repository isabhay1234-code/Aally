package com.allay.app.ai

import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Talks to Google's Gemini REST API. The key goes in a header, never in the URL. */
class GeminiProvider(
    private val apiKey: String,
    model: String,
) : AiProvider {

    private val model = model.trim()

    override suspend fun generate(history: List<ChatTurn>, systemPrompt: String): String =
        withContext(Dispatchers.IO) {
            if (apiKey.isBlank()) throw AiException(AiErrorKind.NO_KEY)
            if (!Regex("[A-Za-z0-9._-]+").matches(model)) throw AiException(AiErrorKind.MODEL_NOT_FOUND)

            val body = GeminiParser.buildRequestBody(history, systemPrompt)
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            val connection = url.openConnection() as HttpURLConnection
            try {
                connection.requestMethod = "POST"
                connection.connectTimeout = 15_000
                connection.readTimeout = 60_000
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", "application/json")
                connection.setRequestProperty("x-goog-api-key", apiKey)
                connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                GeminiParser.parse(code, text)
            } catch (e: IOException) {
                throw AiException(AiErrorKind.NETWORK)
            } finally {
                connection.disconnect()
            }
        }
}
