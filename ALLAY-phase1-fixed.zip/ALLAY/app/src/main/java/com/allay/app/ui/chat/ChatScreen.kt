package com.allay.app.ui.chat

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.allay.app.ai.Role
import com.allay.app.core.AppInfo
import com.allay.app.ui.theme.Cyan
import com.allay.app.ui.theme.Navy

private fun hasMic(context: Context): Boolean =
    ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

@Composable
fun ChatScreen(vm: ChatViewModel, onOpenHistory: () -> Unit, onOpenSettings: () -> Unit) {
    val messages by vm.messages.collectAsStateWithLifecycle()
    val ui by vm.ui.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val listening by vm.voice.listening.collectAsStateWithLifecycle()
    val level by vm.voice.level.collectAsStateWithLifecycle()
    val partial by vm.voice.partial.collectAsStateWithLifecycle()
    val speaking by vm.voice.speaking.collectAsStateWithLifecycle()

    var input by rememberSaveable { mutableStateOf("") }
    val context = LocalContext.current
    val listState = rememberLazyListState()

    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) vm.showNotice("Microphone allowed. Now hold the mic button and speak.")
        else vm.showNotice("Microphone permission denied. You can still type.")
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }

    val orbState = when {
        listening -> OrbState.LISTENING
        ui.loading -> OrbState.THINKING
        speaking -> OrbState.SPEAKING
        else -> OrbState.IDLE
    }
    val status = when {
        listening -> partial.ifBlank { "Listening..." }
        ui.loading -> "Thinking..."
        speaking -> "Speaking..."
        else -> "Hold the mic to talk, or type below"
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding(),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(AppInfo.NAME, style = MaterialTheme.typography.titleLarge, color = Cyan, modifier = Modifier.weight(1f))
            TextButton(onClick = { vm.newChat() }) { Text("New") }
            TextButton(onClick = onOpenHistory) { Text("History") }
            TextButton(onClick = onOpenSettings) { Text("Settings") }
        }

        Column(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            AllayOrb(state = orbState, level = level)
            Text(status, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp, start = 16.dp, end = 16.dp))
        }

        ui.error?.let { error ->
            Surface(
                color = Color(0xFF3A1020),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
            ) {
                Column(Modifier.padding(12.dp)) {
                    Text(error.message, color = Color.White)
                    Row {
                        if (error.canRetry) TextButton(onClick = { vm.retry() }) { Text("Retry") }
                        if (error.needsSettings) TextButton(onClick = onOpenSettings) { Text("Open Settings") }
                        TextButton(onClick = { vm.dismissError() }) { Text("Dismiss") }
                    }
                }
            }
        }

        ui.notice?.let { notice ->
            Surface(
                color = Navy,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(notice, modifier = Modifier.weight(1f).padding(12.dp))
                    TextButton(onClick = { vm.dismissNotice() }) { Text("OK") }
                }
            }
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (messages.isEmpty()) {
                Column(Modifier.align(Alignment.Center).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        if (settings.apiKey.isBlank()) "Add your Gemini API key in Settings to start."
                        else "Say hi in English, Hindi or Hinglish.",
                    )
                    if (settings.apiKey.isBlank()) TextButton(onClick = onOpenSettings) { Text("Open Settings") }
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(messages, key = { it.id }) { m -> Bubble(m.text, fromUser = m.role == Role.USER.name) }
                }
            }
        }

        if (speaking) {
            Button(onClick = { vm.stopSpeaking() }, modifier = Modifier.padding(horizontal = 12.dp)) { Text("Stop speaking") }
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(if (listening) Cyan else Navy)
                    .pointerInput(Unit) {
                        detectTapGestures(onPress = {
                            if (!hasMic(context)) {
                                micPermission.launch(Manifest.permission.RECORD_AUDIO)
                            } else {
                                vm.startVoice()
                                tryAwaitRelease()
                                vm.stopVoice()
                            }
                        })
                    }
                    .semantics {
                        contentDescription = "Hold to talk"
                        onClick(label = "Start or stop listening") {
                            if (listening) vm.stopVoice()
                            else if (hasMic(context)) vm.startVoice()
                            else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                            true
                        }
                    },
                contentAlignment = Alignment.Center,
            ) { Text("\uD83C\uDF99") }

            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f).widthIn(min = 0.dp),
                placeholder = { Text("Message ALLAY") },
                maxLines = 4,
            )
            Button(
                onClick = { vm.send(input); input = "" },
                enabled = input.isNotBlank() && !ui.loading,
            ) { Text("Send") }
        }
    }
}

@Composable
private fun Bubble(text: String, fromUser: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (fromUser) Arrangement.End else Arrangement.Start,
    ) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = if (fromUser) Color(0xFF0B4F66) else Navy,
            modifier = Modifier.widthIn(max = 320.dp),
        ) {
            SelectionContainer { Text(text, modifier = Modifier.padding(12.dp), color = Color.White) }
        }
    }
}
