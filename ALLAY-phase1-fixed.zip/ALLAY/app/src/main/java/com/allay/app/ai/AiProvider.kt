package com.allay.app.ai

enum class Role { USER, ASSISTANT }

data class ChatTurn(val role: Role, val text: String)

/** Every AI service (Gemini now; others later) implements this. The UI never sees HTTP details. */
interface AiProvider {
    /** Returns the assistant's reply text, or throws [AiException]. */
    suspend fun generate(history: List<ChatTurn>, systemPrompt: String): String
}
