package com.allay.app.ui.chat

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.allay.app.ui.theme.Cyan

enum class OrbState { IDLE, LISTENING, THINKING, SPEAKING }

/** The ALLAY orb. It only animates while ALLAY is active, so it costs no battery when idle. */
@Composable
fun AllayOrb(state: OrbState, level: Float, modifier: Modifier = Modifier, orbSize: Dp = 96.dp) {
    val pulse = if (state == OrbState.THINKING || state == OrbState.SPEAKING) {
        val transition = rememberInfiniteTransition(label = "orb")
        transition.animateFloat(
            initialValue = 0.94f,
            targetValue = 1.08f,
            animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
            label = "pulse",
        ).value
    } else {
        1f
    }
    val voiceLevel by animateFloatAsState(if (state == OrbState.LISTENING) level else 0f, label = "level")
    val scale = pulse * (1f + voiceLevel * 0.3f)

    Canvas(
        modifier = modifier
            .size(orbSize)
            .semantics { contentDescription = "ALLAY orb, ${state.name.lowercase()}" },
    ) {
        val radius = this.size.minDimension / 2f * 0.7f * scale
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Cyan.copy(alpha = 0.55f), Cyan.copy(alpha = 0.15f), Color.Transparent),
                center = center,
                radius = radius * 1.45f,
            ),
            radius = radius * 1.45f,
            center = center,
        )
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFFB8F8FF), Cyan, Color(0xFF0A4A6E)),
                center = center,
                radius = radius,
            ),
            radius = radius,
            center = center,
        )
        drawCircle(
            color = Cyan.copy(alpha = 0.6f),
            radius = radius * 1.12f,
            center = center,
            style = Stroke(width = 2.dp.toPx()),
        )
    }
}
