package com.allay.app.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.allay.app.core.TextCleaner
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Push-to-talk speech recognition + text-to-speech, using Android's built-in engines.
 * Must be used from the main thread. Audio is only captured while startListening() is active.
 */
class VoiceController(context: Context) {
    private val app = context.applicationContext

    private val _listening = MutableStateFlow(false)
    val listening: StateFlow<Boolean> = _listening.asStateFlow()
    private val _level = MutableStateFlow(0f)
    val level: StateFlow<Float> = _level.asStateFlow()
    private val _partial = MutableStateFlow("")
    val partial: StateFlow<String> = _partial.asStateFlow()
    private val _speaking = MutableStateFlow(false)
    val speaking: StateFlow<Boolean> = _speaking.asStateFlow()

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pendingSpeech: String? = null

    // ----- Speech to text -----
    fun startListening(languageTag: String, onText: (String) -> Unit, onProblem: (String) -> Unit) {
        stopSpeaking() // let the user interrupt ALLAY by talking
        if (!SpeechRecognizer.isRecognitionAvailable(app)) {
            onProblem("Speech recognition isn't available on this phone.")
            return
        }
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(app)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { _listening.value = true }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) { _level.value = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f) }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { _listening.value = false; _level.value = 0f }
            override fun onError(error: Int) {
                resetListening()
                val message = messageFor(error)
                if (message.isNotEmpty()) onProblem(message)
            }
            override fun onResults(results: Bundle?) {
                resetListening()
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (text.isBlank()) onProblem("I didn't catch that. Try again.") else onText(text)
            }
            override fun onPartialResults(partialResults: Bundle?) {
                _partial.value = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        _listening.value = true
        r.startListening(intent)
    }

    fun stopListening() { recognizer?.stopListening() }

    private fun resetListening() {
        _listening.value = false
        _level.value = 0f
        _partial.value = ""
    }

    private fun messageFor(error: Int): String = when (error) {
        SpeechRecognizer.ERROR_CLIENT -> "" // happens on normal cancel; stay quiet
        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "I didn't catch that. Hold the mic and speak."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is missing."
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Voice input needs an internet connection on this phone."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "The speech recognizer is busy. Try again."
        else -> "Voice input failed (code $error)."
    }

    // ----- Text to speech -----
    fun speak(text: String) {
        val clean = TextCleaner.forSpeech(text).take(3900)
        if (clean.isBlank()) return
        if (tts == null) {
            pendingSpeech = clean
            tts = TextToSpeech(app) { status ->
                ttsReady = status == TextToSpeech.SUCCESS
                if (ttsReady) {
                    tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) { _speaking.value = true }
                        override fun onDone(utteranceId: String?) { _speaking.value = false }
                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) { _speaking.value = false }
                    })
                    pendingSpeech?.let { pendingSpeech = null; speakNow(it) }
                }
            }
            return
        }
        if (!ttsReady) { pendingSpeech = clean; return }
        speakNow(clean)
    }

    private fun speakNow(text: String) {
        val engine = tts ?: return
        val locale = Locale.forLanguageTag(if (TextCleaner.hasDevanagari(text)) "hi-IN" else "en-IN")
        val result = engine.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            engine.setLanguage(Locale.getDefault())
        }
        _speaking.value = true
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "allay-utterance")
    }

    fun stopSpeaking() {
        pendingSpeech = null
        tts?.stop()
        _speaking.value = false
    }

    fun release() {
        recognizer?.destroy(); recognizer = null
        tts?.stop(); tts?.shutdown(); tts = null; ttsReady = false
    }
}
