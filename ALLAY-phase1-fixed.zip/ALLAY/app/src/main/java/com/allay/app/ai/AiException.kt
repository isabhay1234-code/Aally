package com.allay.app.ai

enum class AiErrorKind(
    val message: String,
    val needsSettings: Boolean = false,
    val retryable: Boolean = false,
) {
    NO_KEY("Add your Gemini API key in Settings first.", needsSettings = true),
    INVALID_KEY("Gemini rejected the API key. Check it in Settings.", needsSettings = true),
    QUOTA("Gemini's usage limit was reached. Wait a little, then retry.", retryable = true),
    NETWORK("Couldn't reach Gemini. Check your internet connection, then retry.", retryable = true),
    SERVER("Gemini is having problems right now. Retry in a moment.", retryable = true),
    BLOCKED("Gemini declined to answer that. Try rewording your message."),
    EMPTY("Gemini sent an empty reply. Retry or reword your message.", retryable = true),
    MODEL_NOT_FOUND("That model name isn't available. Check the model in Settings.", needsSettings = true),
    BAD_REQUEST("Gemini couldn't process the request. Try a shorter message."),
    UNKNOWN("Something unexpected went wrong. Retry.", retryable = true),
}

class AiException(val kind: AiErrorKind, val detail: String? = null) : Exception(detail ?: kind.message)
