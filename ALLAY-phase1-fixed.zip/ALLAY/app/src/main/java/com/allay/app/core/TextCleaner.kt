package com.allay.app.core

/** Small text helpers (pure Kotlin, unit tested). */
object TextCleaner {
    private val markdownChars = Regex("[*#`_~>]")
    private val spaces = Regex("\\s+")

    /** Removes markdown symbols so text-to-speech doesn't read "asterisk asterisk". */
    fun forSpeech(text: String): String =
        text.replace(markdownChars, "").replace(spaces, " ").trim()

    /** True if the text contains Hindi (Devanagari) letters. */
    fun hasDevanagari(text: String): Boolean = text.any { it in '\u0900'..'\u097F' }
}
