package com.allay.app.data

import com.allay.app.ai.ChatTurn
import com.allay.app.ai.Role
import kotlinx.coroutines.flow.Flow

/** Local chat history only. (Long-term "memory" is a separate system, planned for Phase 3.) */
class ChatRepository(private val dao: ChatDao) {
    fun conversations(): Flow<List<ConversationEntity>> = dao.conversations()
    fun messages(conversationId: Long): Flow<List<MessageEntity>> = dao.messages(conversationId)

    suspend fun newConversation(title: String): Long {
        val now = System.currentTimeMillis()
        return dao.insertConversation(ConversationEntity(title = title, createdAt = now, updatedAt = now))
    }

    suspend fun addMessage(conversationId: Long, role: Role, text: String) {
        val now = System.currentTimeMillis()
        dao.insertMessage(MessageEntity(conversationId = conversationId, role = role.name, text = text, createdAt = now))
        dao.touch(conversationId, now)
    }

    /** Last [limit] messages, oldest first. Only these are sent to the AI, not the whole history. */
    suspend fun recentTurns(conversationId: Long, limit: Int): List<ChatTurn> =
        dao.recent(conversationId, limit).reversed().map { ChatTurn(Role.valueOf(it.role), it.text) }

    suspend fun delete(conversationId: Long) = dao.deleteConversation(conversationId)
    suspend fun clearAll() = dao.deleteAll()
}
