package com.allay.app

import android.app.Application
import androidx.room.Room
import com.allay.app.data.ChatDatabase
import com.allay.app.data.ChatRepository
import com.allay.app.data.SettingsRepository

/** Creates shared objects once (simple manual dependency injection). */
class AllayApp : Application() {
    private val database by lazy { Room.databaseBuilder(this, ChatDatabase::class.java, "allay.db").build() }
    val chatRepository by lazy { ChatRepository(database.chatDao()) }
    val settingsRepository by lazy { SettingsRepository(this) }
}
