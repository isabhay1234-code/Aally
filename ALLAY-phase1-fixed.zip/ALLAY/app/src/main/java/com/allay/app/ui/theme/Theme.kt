package com.allay.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Cyan = Color(0xFF00E5FF)
val DeepBlack = Color(0xFF050A14)
val Navy = Color(0xFF0A1428)

private val AllayColors = darkColorScheme(
    primary = Cyan,
    background = DeepBlack,
    surface = Navy,
    onBackground = Color.White,
    onSurface = Color.White,
)

@Composable
fun AllayTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = AllayColors, content = content)
}
