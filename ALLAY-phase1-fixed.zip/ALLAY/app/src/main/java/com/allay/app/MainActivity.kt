package com.allay.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.allay.app.ui.HistoryScreen
import com.allay.app.ui.SettingsScreen
import com.allay.app.ui.chat.ChatScreen
import com.allay.app.ui.chat.ChatViewModel
import com.allay.app.ui.theme.AllayTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { AllayTheme { AllayRoot() } }
    }
}

@Composable
private fun AllayRoot() {
    val vm: ChatViewModel = viewModel()
    var screen by rememberSaveable { mutableStateOf("chat") }
    BackHandler(enabled = screen != "chat") { screen = "chat" }

    when (screen) {
        "history" -> HistoryScreen(
            vm = vm,
            onBack = { screen = "chat" },
            onOpen = { id -> vm.openConversation(id); screen = "chat" },
        )
        "settings" -> SettingsScreen(vm = vm, onBack = { screen = "chat" })
        else -> ChatScreen(
            vm = vm,
            onOpenHistory = { screen = "history" },
            onOpenSettings = { screen = "settings" },
        )
    }
}
