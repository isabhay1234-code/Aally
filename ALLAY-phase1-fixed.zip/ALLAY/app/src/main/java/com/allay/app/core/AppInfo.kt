package com.allay.app.core

object AppInfo {
    const val NAME = "ALLAY"
    const val TAGLINE = "Your Intelligence. Your Control."
}
