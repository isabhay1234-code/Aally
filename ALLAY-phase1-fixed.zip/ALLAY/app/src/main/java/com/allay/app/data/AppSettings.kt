package com.allay.app.data

enum class ResponseLength(val label: String) { SHORT("Short"), BALANCED("Balanced"), DETAILED("Detailed") }

enum class ChatStyle(val label: String) { FRIENDLY("Friendly"), PROFESSIONAL("Professional"), TEACHER("Teacher") }

enum class VoiceLanguage(val label: String, val tag: String) {
    ENGLISH("English (India)", "en-IN"),
    HINDI("Hindi", "hi-IN"),
}

data class AppSettings(
    val apiKey: String = "",
    val model: String = DEFAULT_MODEL,
    val length: ResponseLength = ResponseLength.BALANCED,
    val style: ChatStyle = ChatStyle.FRIENDLY,
    val voiceLanguage: VoiceLanguage = VoiceLanguage.ENGLISH,
    val speakReplies: Boolean = false,
) {
    companion object {
        /** Change this in Settings if Google retires the model. */
        const val DEFAULT_MODEL = "gemini-2.5-flash"
    }
}
