# Checklist

## Phase 0 — done (code), build unverified
## Phase 1 — Core assistant: CODE WRITTEN, NOT BUILT, NOT TESTED
- [x] UI + orb  - [x] Chat  - [x] Gemini  - [x] Voice in  - [x] TTS  - [x] History  - [x] Settings  - [x] Errors
- [ ] CI build green (you)
- [ ] Unit tests pass in CI (you)
- [ ] Phone test list in README completed (you)
- [ ] You review Phase 1 -> then Phase 2

## Phases 2–8: not started
## Cannot be verified in my sandbox
Compiling, running tests, Gemini calls, microphone/TTS, UI on a real device.

## Verification log
- Review 1 (no compiler available): static read of every Phase 1 file.
  - FOUND + FIXED: `AllayOrb.kt` was missing `import androidx.compose.animation.core.animateFloat` (would have failed compilation).
  - Changed `VoiceController.kt` to call `setLanguage(...)` explicitly (safer than the property form).
  - Added a "Check project layout" step to the CI workflow.
  - Still NOT compiled, NOT run, NOT tested. Only a real build (GitHub Actions) can confirm.
