# ALLAY Architecture (Phase 1)

Single `app` module, one package per planned module (split into Gradle modules later if needed).

```
UI (Compose)  ->  ChatViewModel  ->  ChatRepository (Room)   ->  local DB
                               \->  SettingsRepository (DataStore + Keystore-encrypted key)
                               \->  AiProvider  <- GeminiProvider (HTTPS, key in header)
                               \->  VoiceController (SpeechRecognizer + TextToSpeech)
```
- `ai/`: `AiProvider` interface, `GeminiProvider` (network), `GeminiParser` (pure, tested), `PromptBuilder`, `AiException` (typed errors -> friendly messages)
- `data/`: Room entities/DAO, repositories, settings model
- `security/`: `KeyCipher` (AES-GCM, Android Keystore)
- `voice/`: push-to-talk + TTS
- `ui/`: screens (Chat, History, Settings), orb, theme
- `core/`: shared helpers
- Empty for now: `research, study, memory, automation, coding`

Design choices: HttpURLConnection + org.json instead of Retrofit (fewer dependencies, less to break; easy to swap later). Manual DI via `AllayApp`. Only the last 20 messages are sent per request; long-term memory is a separate Phase 3 system.

Versions: AGP 8.7.3, Kotlin 2.0.21, KSP 2.0.21-1.0.28, Compose BOM 2024.12.01, Room 2.6.1, DataStore 1.1.1, Gradle 8.11.1, JDK 17, SDK 35, minSdk 26. (Unverified until first CI build.)
